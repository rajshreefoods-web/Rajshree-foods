# Rajshree Foods — website starter

A responsive, custom-coded website starter for Rajshree Foods. It includes:
- A first-screen choice for direct customers or retailers/resellers
- Product categories: pickles, chutneys, ladoos and more
- Product cards and a cart UI
- Pincode-based delivery-fee configuration
- Retailer contact links
- Homemade process / video placeholders
- FAQ section
- Mobile-friendly layout

## Preview locally
Open `index.html` in a browser. No build tools are required.

## Put it on GitHub
1. Create a **public** repository called `rajshree-foods-website`.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
5. GitHub will show your website URL after deployment.

## Before going live
Edit the `CONFIG` object at the top of `script.js`:
- Add confirmed product names, prices, pack sizes, and descriptions.
- Add your business WhatsApp number (digits only, with country code), email, and phone.
- Add actual serviceable pincodes and delivery fees to `shippingByPincode`.
- Add a default delivery fee only if you want a single rate for other pincodes.
- Replace the sample product-art placeholders with your real product images and add your kitchen videos.
- Update shelf-life, cancellation, delivery and store information in `index.html`.

## Important checkout note
This starter intentionally does **not** collect payments or card details. It provides a cart and a configurable order enquiry flow. To take payment directly on the website, you'll need a payment provider account (for example, Razorpay) and a secure server-side integration; never put secret API keys in front-end JavaScript. Shipping charges also need a verified pincode/rate policy before launch.

## Add real photos and video
Create an `assets` folder and add your files there, then update the relevant markup in `index.html` and product data in `script.js`. Use your circular logo in the header by replacing the `RF` text inside `.logo-mark` with an `<img>` tag and keeping `border-radius:50%` in CSS.
