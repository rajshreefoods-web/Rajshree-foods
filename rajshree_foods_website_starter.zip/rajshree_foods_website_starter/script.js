/*
  RAJSHREE FOODS — starter configuration
  Update the CONFIG object below before launch.
  Online payments are intentionally not activated in this starter.
*/
const CONFIG = {
  whatsappNumber: "", // Example: "919876543210" (country code + number, digits only)
  businessEmail: "", // Example: "hello@rajshreefoods.in"
  businessPhone: "", // Example: "+919876543210"
  currency: "₹",
  // Add confirmed PIN codes and delivery charges here. Example:
  // "400053": 40, "400058": 50
  shippingByPincode: {},
  defaultDeliveryCharge: null, // Set a number only after deciding your policy
  products: [
    {id:"pickle-mango",name:"Homestyle Mango Pickle",category:"pickle",description:"A tangy, familiar favourite for everyday meals.",price:null,weight:"Add pack size",emoji:"🥭",bg:"#f2dfbd",badge:"Pantry favourite"},
    {id:"pickle-mixed",name:"Mixed Pickle",category:"pickle",description:"A classic mix for the side of your plate.",price:null,weight:"Add pack size",emoji:"🫙",bg:"#ecd8ad",badge:"Small batch"},
    {id:"chutney-garlic",name:"Homemade Garlic Chutney",category:"chutney",description:"A bold, flavourful companion for your meals.",price:null,weight:"Add pack size",emoji:"🌶️",bg:"#ead0b9",badge:"Homemade"},
    {id:"chutney-coconut",name:"Dry Coconut Chutney",category:"chutney",description:"A delicious dry chutney for a quick flavour boost.",price:null,weight:"Add pack size",emoji:"🥥",bg:"#e8e2c9",badge:"Pantry favourite"},
    {id:"ladoo",name:"Homestyle Ladoo",category:"ladoo",description:"A sweet little treat for everyday moments.",price:null,weight:"Add pack size",emoji:"🟠",bg:"#f0d9a5",badge:"Sweet treat"},
    {id:"makhana",name:"Roasted Makhana",category:"other",description:"A light, crunchy snack for your snack shelf.",price:null,weight:"Add pack size",emoji:"🍿",bg:"#e2e8d8",badge:"Snack time"}
  ]
};

const state = { cart: {}, category: "all", pincode: "", delivery: null };
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const money = (n) => n == null ? "Price to be added" : `${CONFIG.currency}${Number(n).toLocaleString("en-IN")}`;
function toast(message) {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
function renderProducts() {
  const products = CONFIG.products.filter(p => state.category === "all" || p.category === state.category);
  $("#productGrid").innerHTML = products.map(p => `
    <article class="product-card">
      <div class="product-art" style="--product-bg:${p.bg}">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ""}
        <span class="product-emoji" aria-hidden="true">${p.emoji || "🍲"}</span>
      </div>
      <div class="product-info">
        <span class="product-category">${p.category}</span>
        <h3>${p.name}</h3><p class="product-description">${p.description}</p>
        <div class="product-bottom"><span class="product-price">${money(p.price)}<small class="product-weight">${p.weight}</small></span>
          <button class="add-button" data-add="${p.id}">${p.price == null ? "Preview item +" : "Add to bag +"}</button>
        </div>
      </div>
    </article>`).join("");
}
function cartCount() { return Object.values(state.cart).reduce((sum, item) => sum + item.qty, 0); }
function subtotal() { return Object.values(state.cart).reduce((sum, item) => sum + (item.product.price || 0) * item.qty, 0); }
function renderCart() {
  const entries = Object.values(state.cart);
  $("#cartCount").textContent = cartCount();
  $("#drawerCount").textContent = `(${cartCount()})`;
  $("#cartSubtotal").textContent = money(subtotal());
  $("#deliveryCost").textContent = state.delivery == null ? "To be confirmed" : money(state.delivery);
  $("#cartItems").innerHTML = entries.length ? entries.map(({product:p,qty}) => `
    <div class="cart-item"><div><strong>${p.name}</strong><small>${p.weight} · ${money(p.price)}</small>
      <div class="quantity-controls"><button data-qty="${p.id}" data-delta="-1" aria-label="Remove one">−</button><span>${qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Add one">+</button></div>
    </div><strong>${p.price == null ? "—" : money(p.price * qty)}</strong></div>`).join("") : `<p class="empty-cart">Your bag is waiting for something delicious.</p>`;
}
function openCart() { $("#cartOverlay").classList.add("open"); $("#cartOverlay").setAttribute("aria-hidden","false"); document.body.style.overflow="hidden"; }
function closeCart() { $("#cartOverlay").classList.remove("open"); $("#cartOverlay").setAttribute("aria-hidden","true"); document.body.style.overflow=""; }
function retailerMessage() {
  const text = "Hi Rajshree Foods! I’m interested in stocking your products. Please share your wholesale catalogue and retailer terms.";
  if (CONFIG.whatsappNumber) return `https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(text)}`;
  return "#";
}
function setupRetailerLinks() {
  $("#retailerWhatsApp").href = retailerMessage();
  $("#retailerEmail").href = CONFIG.businessEmail ? `mailto:${CONFIG.businessEmail}?subject=${encodeURIComponent("Retailer enquiry - Rajshree Foods")}` : "#";
  $("#retailerCall").href = CONFIG.businessPhone ? `tel:${CONFIG.businessPhone.replace(/\s/g,"")}` : "#";
}
function selectAudience(which) {
  if (which === "customer") { $("#shop").scrollIntoView({behavior:"smooth"}); }
  else { $("#retailer").scrollIntoView({behavior:"smooth"}); }
}
$("#chooseCustomer").addEventListener("click", () => selectAudience("customer"));
$("#chooseRetailer").addEventListener("click", () => selectAudience("retailer"));
$$("[data-view='retailer']").forEach(b => b.addEventListener("click", () => selectAudience("retailer")));
$$(".category-tab").forEach(b => b.addEventListener("click", () => {
  state.category = b.dataset.category;
  $$(".category-tab").forEach(x => x.classList.toggle("active", x === b));
  renderProducts();
}));
$("#productGrid").addEventListener("click", e => {
  const btn = e.target.closest("[data-add]"); if (!btn) return;
  const product = CONFIG.products.find(p => p.id === btn.dataset.add);
  if (product.price == null) { toast("Sample item: add its confirmed price before accepting orders."); return; }
  if (!state.cart[product.id]) state.cart[product.id] = {product, qty:0};
  state.cart[product.id].qty++; renderCart(); toast(`${product.name} added to your bag.`);
});
$("#cartItems").addEventListener("click", e => {
  const btn = e.target.closest("[data-qty]"); if (!btn) return;
  const id = btn.dataset.qty; if (!state.cart[id]) return;
  state.cart[id].qty += Number(btn.dataset.delta);
  if (state.cart[id].qty <= 0) delete state.cart[id];
  renderCart();
});
$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
$("#closeCartBackdrop").addEventListener("click", closeCart);
$("#checkPincode").addEventListener("click", () => {
  const pin = $("#pincode").value.trim();
  if (!/^\d{6}$/.test(pin)) { $("#shippingMessage").textContent = "Please enter a valid 6-digit Indian pincode."; return; }
  state.pincode = pin;
  if (Object.prototype.hasOwnProperty.call(CONFIG.shippingByPincode, pin)) {
    state.delivery = CONFIG.shippingByPincode[pin];
    $("#shippingMessage").textContent = `Delivery charge for ${pin}: ${money(state.delivery)}.`;
  } else if (CONFIG.defaultDeliveryCharge != null) {
    state.delivery = CONFIG.defaultDeliveryCharge;
    $("#shippingMessage").textContent = `Estimated delivery charge for ${pin}: ${money(state.delivery)}. Please confirm serviceability before dispatch.`;
  } else {
    state.delivery = null;
    $("#shippingMessage").textContent = `Pincode ${pin} entered. Delivery coverage and fee are not configured yet—please contact us to confirm.`;
  }
  renderCart();
});
$("#checkoutButton").addEventListener("click", () => {
  const items = Object.values(state.cart);
  if (!items.length) { toast("Add a product to your bag first."); return; }
  if (items.some(i => i.product.price == null)) { toast("Please add confirmed prices to the catalogue before checkout."); return; }
  if (!state.pincode) { toast("Enter your delivery pincode first."); $("#pincode").focus(); return; }
  if (state.delivery == null) { toast("Delivery fee isn't configured for this pincode yet."); return; }
  const lines = items.map(i => `${i.product.name} x ${i.qty} — ${money(i.product.price * i.qty)}`).join("\n");
  const total = subtotal() + state.delivery;
  const msg = `Hello Rajshree Foods, I'd like to place an order:\n${lines}\nPincode: ${state.pincode}\nSubtotal: ${money(subtotal())}\nDelivery: ${money(state.delivery)}\nTotal: ${money(total)}\nPlease confirm availability and payment details.`;
  if (CONFIG.whatsappNumber) window.open(`https://wa.me/${CONFIG.whatsappNumber}?text=${encodeURIComponent(msg)}`, "_blank", "noopener");
  else toast("Add your business WhatsApp number in script.js to enable order enquiries.");
});
$("#menuToggle").addEventListener("click", () => {
  const nav = $(".desktop-nav");
  const open = nav.style.display === "flex";
  nav.style.display = open ? "" : "flex";
  if (!open) { nav.style.position="absolute"; nav.style.top="72px"; nav.style.left="0"; nav.style.right="0"; nav.style.padding="20px 6%"; nav.style.background="var(--paper)"; nav.style.flexDirection="column"; nav.style.borderBottom="1px solid var(--line)"; }
});
$("#year").textContent = new Date().getFullYear();
renderProducts(); renderCart(); setupRetailerLinks();
